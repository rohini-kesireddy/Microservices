package com.ltts.DetailInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DetailInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
